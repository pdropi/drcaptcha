<?php
/**
* drcaptcha Roundcube Webmail plugin
*
* More secure login to Roundcube
*
* @version 1.2
* @license GNU GPLv3+
* @author Dejan Roncevic
* @collaborator pdropi
* @website https://github.com/pdropi/drcaptcha/
*/
class drcaptcha extends rcube_plugin
{
	public $task = 'login|logout';
	public $noajax	= true;
	public $noframe = true;
	protected $capimg;
	protected $capcode;
	private $image_height = 45;
	private $image_width;	
	private $font_factor = 0.75;
	private $characters = '23456789ABCDEFGHKMNPRSTVWXYZ';
	private $codesize  = 3;
	private $text_colour = '#707070';
	private $num_lines = 4;
	private $error_delay = 5;
	protected $font;

	public function init(){
		$this->load_config();
		$rcmail = rcmail::get_instance();
		$proxy_option= $rcmail->config->get('proxy_opition','');
		$whitelist_option = $rcmail->config->get('drcaptcha_whitelist','');
		$this->add_texts('localization/', false);
		if ( ! $this->isWhitelisted($whitelist_option,$proxy_option) and ! $this->show_after($rcmail,$proxy_option) ) {
			$this->add_hook('template_object_loginform', array($this,'login_form'));
			$this->add_hook('authenticate', array($this, 'authenticate'));
			$this->add_hook('session_destroy', array($this, 'ses_des'));
		}
	}

	public function login_form($args){
		if (isset($_POST['drcaptcha'])) unset( $_POST['drcaptcha']);
	
		$this->load_config();
		$rcmail = rcmail::get_instance();
		$this->image_height = $rcmail->config->get('drcaptcha_height',45);
		$this->codesize = $rcmail->config->get('drcaptcha_codesize',3);
		$this->characters = $rcmail->config->get('drcaptcha_characters','23456789ABCDEFGHKMNPRSTVWXYZ');
		$this->font_factor = $rcmail->config->get('drcaptcha_font_factor',0.75);
		$this->text_colour = $rcmail->config->get('drcaptcha_text_colour','#707070');
		$this->generateImage();
		$bimg = base64_encode($this->capimg);
		$imgattr['src'] = 'data:image/gif;base64,'.$bimg;
		$img_captcha = html::img($imgattr);
		
		$table = new html_table(array('cols' => 2));
		$input_captcha	 = new html_inputfield(array('name' => '_captcha', 'id' => 'drcaptcha', 'title'=>'drcaptcha')); //'value' => $this->capcode
		$table->add('title', html::label('drcaptcha',$this->gettext('drcaptcha.capplaceholder')));
		$table->add('input',$input_captcha->show() );
		$table->add('captcha',$img_captcha) ;
		$pos = $pos = strpos( $args['content'], '<p class="formbuttons"');
		if ($pos === false) $args['content'] .= $table->show() ;
		else $args['content'] = substr($args['content'], 0, $pos) . $table->show() . substr($args['content'], $pos); ;
		$_SESSION['drcaptcha'] = $this->capcode; 
		
		return $args;
	} 

	public function authenticate($args){
		$this->load_config();
		$rcmail = rcmail::get_instance();
		if (@strtoupper(@$_POST['drcaptcha']) != @strtoupper(@$_POST['_captcha']) ) {
			$args['abort'] = 1; 
			$args['error'] = 'drcaptcha.captchafailed';
			$this->error_delay = $rcmail->config->get('drcaptcha_error_delay',5);
			sleep($this->error_delay);
			rcube::write_log('errors', 'Wrong captcha from ip: '.$this->get_client_ip($rcmail->config->get('proxy_opition','')));
		}
		if (isset($_POST['drcaptcha'])) unset( $_POST['drcaptcha']);

		return $args;
	}

	public function ses_des(){
		//Preserve drcaptcha session variable in post to survive session_destroy caled before authenticate 
		@$_POST['drcaptcha'] = @$_SESSION['drcaptcha'];
	}

	private function generateCode () {
		$code = ''; $i = 0;
		while ($i < $this->codesize ) { 
			$code .= substr($this->characters, mt_rand(0, strlen($this->characters)-1), 1);
			$i++;
		}
		return $code;
	}

	private function generateImage () {
		$this->font = dirname(__FILE__) . '/AHGBold.ttf';
		$code = $this->generateCode();
		$this->capcode = $code; 


		/* seed random number gen to produce the same noise pattern time after time */
		mt_srand(crc32($code));	

		/* init image */
		$font_size = $this->image_height * $this->font_factor;
		$textbox = imagettfbbox($font_size, 0, $this->font, $code) or die('Error in imagettfbbox function');
		$textwidth = abs($textbox[4] - $textbox[0]); $textheight = abs($textbox[5] - $textbox[1]);
		$this->image_width = ($textwidth+$this->image_height - $textheight);
		$image = @imagecreate($this->image_width, $this->image_height) or die('Cannot initialize new GD image stream');
		$colr = $this->hex2rgb($this->text_colour);
		
		/* set the colours */
		$background_color = imagecolorallocate($image, 0, 0, 0);
		$text_color = imagecolorallocate($image, $colr['r'],$colr['g'],$colr['b']);
		$noise_color = imagecolorallocate($image, $colr['r']+30,  $colr['g']+30,  $colr['b']+30);

		/* create textbox and add text */
		$x = ($this->image_width - $textbox[4])/2;
		$y = ($this->image_height - $textbox[5])/2;
		$d = -1;

		imagettftext( $image, $font_size, 0, $x + $d, $y + $d, $noise_color, $this->font , $code)
		or die('Error in imagettftext function');
		imagettftext( $image, $font_size, 0, $x + 2 * $d + 1, $y + 2 * $d + 1, $noise_color, $this->font , $code) 
		or die('Error in imagettftext function');
		imagettftext( $image, $font_size, 0, $x + 3 * $d, $y + 2 * $d, $background_color, $this->font , $code) 
		or die('Error in imagettftext function');

		/* mix in background dots */
		for( $i=0; $i<($this->image_width*$this->image_height)/10; $i++ ) { 
			imagefilledellipse($image, mt_rand(0,$this->image_width), mt_rand(0,$this->image_height), 1, 1, $background_color);
		}

		/* mix in text and noise dots */
		for( $i=0; $i<($this->image_width*$this->image_height)/30; $i++ ) {
			$ef = 25;
			$wr = mt_rand(0,$this->image_width); $hr = mt_rand(0,$this->image_height);

			imagefilledellipse($image, mt_rand(0,$this->image_width), mt_rand(0,$this->image_height), 1, 1, $noise_color);
			imagefilledellipse($image, mt_rand(0,$this->image_width), mt_rand(0,$this->image_height), 1, 1, $text_color);
		}
		// Draw Background Lines
		for ($line = 0; $line < $this->num_lines; ++ $line) {
			$x = $this->image_width * (1 + $line) / ($this->num_lines + 1);
			$x += (0.5 - $this->frand()) * $this->image_width / $this->num_lines;
			$y = mt_rand($this->image_height * 0.1, $this->image_height * 0.9);

			$theta = ($this->frand() - 0.5) * M_PI * 0.7;
			$w = $this->image_width;
			$len = mt_rand($w * 0.4, $w * 0.7); $lwid = mt_rand(0, 2);

			$k = $this->frand() * 0.6 + 0.2;
			$k = $k * $k * 0.5; $phi = $this->frand() * 6.28;
			$step = 0.5; $dx = $step * cos($theta);
			$dy = $step * sin($theta); $n = $len / $step;
			$amp = 1.5 * $this->frand() / ($k + 5.0 / $len);
			$x0 = $x - 0.5 * $len * cos($theta); $y0 = $y - 0.5 * $len * sin($theta);

			$ldx = round(- $dy * $lwid); $ldy = round($dx * $lwid);

			for ($i = 0; $i < $n; ++ $i) {
				$x = $x0 + $i * $dx + $amp * $dy * sin($k * $i * $step + $phi);
				$y = $y0 + $i * $dy - $amp * $dx * sin($k * $i * $step + $phi);
				imagefilledrectangle($image, $x, $y, $x + $lwid,$y + $lwid, $background_color);
			}
		}
		/* rotate a bit to add fuzziness */
		$image = imagerotate($image, 1, $background_color);
		// Make transparent
		imagecolortransparent($image, $background_color);
		imagealphablending($image, true);
		ob_start();

		imagepng($image);
		// Capture the output
		$cimage = ob_get_contents();

		// Clear the output buffer
		ob_end_clean();

		imagedestroy($image);
		$this->capimg = $cimage;
	}

	private function hex2rgb($c)
	{
		if(!$c) return false;
		$c = trim($c);
		$out = false;
		if(preg_match("/^[0-9ABCDEFabcdef\#]+$/i", $c)){
			$c = str_replace('#','', $c);
			$l = strlen($c) == 3 ? 1 : (strlen($c) == 6 ? 2 : false);
			if($l){
				unset($out);
				$out[0] = $out['r'] = $out['red'] = hexdec(substr($c, 0,1*$l));
				$out[1] = $out['g'] = $out['green'] = hexdec(substr($c, 1*$l,1*$l));
				$out[2] = $out['b'] = $out['blue'] = hexdec(substr($c, 2*$l,1*$l));
			}else $out = false;
		}else $out = false;
		return $out;
	}

	//Return a random float between 0 and 0.9999  . @return float Random float between 0 and 0.9999
	function frand() { return 0.0001 * mt_rand(0,9999); }

	//transforma ip to bin pra verificar a subnet
	private function ip2bin($x){
		preg_match_all("/[0-9]{1,3}/","$x",$a);
		$b=array_map("decbin",$a[0]);
		//	  $c=@array_map("fill0",$b);
		$p2=array(8,8,8,8);
		$p3=array('0','0','0','0');
		$p4=array(STR_PAD_LEFT, STR_PAD_LEFT, STR_PAD_LEFT, STR_PAD_LEFT);
		$c=array_map("str_pad",$b,$p2,$p3,$p4);
		return ("$c[0]$c[1]$c[2]$c[3]");
	}

	//Avalia se o ip pertence a rede informada ou nao
	private function isInNet($net,$proxy_option) {
		$net = trim($net);
		if ($net == null) return false; // se não foi definida rede retorna falso
		$ip= $this->get_client_ip($proxy_option);
		if ($net == $ip) return true; // se for o proprio ip retorna verdadeiro
		if (strpos($net,"/") > 1) { //calcula se percence aa subnet
			$subnet=explode('/',$net);
			$netip = $this->ip2bin($ip); // binario do ip
			$netnet = $this->ip2bin($subnet[0]); // binario da rede
			$ret=($netnet & $netip);
			return ($netnet === $ret);
		}
		return false;
	}

	private function isWhitelisted($netss,$proxy_option) {
		$nets = explode(',', $netss);
		foreach($nets as $net) {
			if ( $this-> isInNet($net,$proxy_option) ) return true;
		}  
		return false;
	}

	private function get_client_ip($proxy_option){
		if($proxy_option == 'real') return $_SERVER['REMOTE_ADDR'];
		elseif($proxy_option == 'X-Forwarded-For') return strtok($_SERVER['HTTP_X_FORWARDED_FOR'],',');
		elseif($proxy_option == 'CF-Connecting-IP') return $_SERVER['HTTP_CF_CONNECTING_IP'];
		else {echo ' - Return what? '; return false;}
	}
	//check for previous failed logins
	private function show_after($rcmail,$proxy_option){
		$show_after = $rcmail->config->get('show_after',0);
		if($show_after>0){
			if ($rcmail->config->get('log_driver')=='file'){
			$log_dir = $rcmail->config->get('log_dir');
			$log_ext = $rcmail->config->get('log_file_ext');
			$log_file = fopen("$log_dir/errors$log_ext", 'r'); //open roundcube error log file
			}else {
				$log_file = false; 
				echo 'Please set $show_after=0; in drcaptcha config or adapt code to your log format set in log_driver config ('.$rcmail->config->get('log_driver').')';
			}
			if (!$log_file) echo ' - Where is logfile?';
			else{
				//Dont't load entire file to memory. Faster and good for big log files
				fseek($log_file, 0, SEEK_END); //move cursor to the end of the file
				/* help functions: */
				//moves cursor one step back if can - returns true, if can't - returns false
				function moveOneStepBack( &$f ){ 
					if( ftell($f) > 0 ){ fseek($f, -1, SEEK_CUR); return true; }
					else return false;
				}
				//reads $length chars and moves cursor back 
				function readNotSeek( &$f, $length ){ 
					$r = fread($f, $length);
					fseek($f, -$length, SEEK_CUR);
					return $r;	
				}

				$rc_log_date_format = $rcmail->config->get('log_date_format','d-M-Y H:i:s O');
				$checked_timestamp = time();
				$until_timestamp  = $checked_timestamp - $rcmail->config->get('check_interval',0.5)*3600;
				$charCounter = 0; $line_date = ''; $line_msg = ''; $found_login_fails = isset($_POST['login_failed'])?1:0;
				while( moveOneStepBack( $log_file ) and $show_after > $found_login_fails){
					if(readNotSeek($log_file, 1) == "["){ 
						$line = $charCounter>0? readNotSeek( $log_file, $charCounter ): ''; 
						$charCounter = 0;
						if (strpos($line, ']') !== false) {
							list($line_date, $line_msg) = explode(']',$line, 2); //split line
							$ldate = @date_create_from_format($rc_log_date_format, substr($line_date,1));
							if($ldate){ 
								$checked_timestamp = $ldate->format("U");
								if($until_timestamp > $checked_timestamp) break; //resources friendly, check only until interval limit. 
								elseif(strpos($line_msg, ' Login failed ') !== false){
									if($proxy_option == 'real')
										$ip_from_log = strtok(substr($line_msg,strpos($line_msg,' from ')+6),' ');
									elseif($proxy_option == 'X-Forwarded-For')
										$ip_from_log = 
										strtok(strtok(substr($line_msg,strpos($line_msg,'X-Forwarded-For: ')+17),')'),',');
									else echo 'Implement condition to get ip_from_log in this line() or change proxy_option'; 
									if($ip_from_log == $this->get_client_ip($proxy_option)) $found_login_fails++;
								}
							}
						}
					}
					$charCounter++; 
				}
				//echo $found_login_fails;
				fclose( $log_file );
				return $show_after > $found_login_fails;
			}
		}
	}
	
} #end class
